package br.com.criandoapi.projeto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import br.com.criandoapi.projeto.DAO.ICliente;
import br.com.criandoapi.projeto.model.Cliente;
import br.com.criandoapi.projeto.model.Contato;

import java.util.List;


@RestController
@CrossOrigin("*")
@RequestMapping("/clientes")
public class ClienteController {

    @Autowired
    private ICliente clienteRepository;

    @PostMapping
 //@RequestBody converte o JSON da requisição para um objeto Clientez
    public ResponseEntity<Cliente> criarCliente(@RequestBody Cliente cliente) {
        System.out.println("JSON recebido: " + cliente);
        System.out.println("Data de Nascimento: " + cliente.getDataNascimento());

       
        if (cliente.getContatos() != null) {
            
            for (Contato contato : cliente.getContatos()) {
                contato.setCliente(cliente);  //Associando o contato ao cliente
            }
        }

        //Salva o cliente com os contatos
        Cliente savedCliente = clienteRepository.save(cliente);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedCliente);
    }



    @GetMapping
    public List<Cliente> listarClientes() {
        return (List<Cliente>) clienteRepository.findAll();
    }
    @GetMapping("/{id}")
    public ResponseEntity<Cliente> obterCliente(@PathVariable Integer id) {
        Cliente cliente = clienteRepository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente não encontrado"));
        return ResponseEntity.ok(cliente);
    }

    @DeleteMapping("/{id}")
    public void excluirCliente(@PathVariable Integer id) {
        if (!clienteRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente não encontrado");
        }
        clienteRepository.deleteById(id);
    }
    
    @PutMapping("/{id}")
    @CrossOrigin(origins = "*")
    public ResponseEntity<Cliente> editarCliente(@PathVariable Integer id, @RequestBody Cliente cliente) {
        Cliente clienteExistente = clienteRepository.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Cliente não encontrado"));

        //Atualizando os campos do cliente
        clienteExistente.setNome(cliente.getNome());
        clienteExistente.setCpf(cliente.getCpf());
        clienteExistente.setDataNascimento(cliente.getDataNascimento());
        clienteExistente.setEndereco(cliente.getEndereco());

        if (cliente.getContatos() != null) {
            clienteExistente.getContatos().clear(); 
            for (Contato contato : cliente.getContatos()) {
                contato.setCliente(clienteExistente);
                clienteExistente.getContatos().add(contato);
            }
        }

        Cliente clienteAtualizado = clienteRepository.save(clienteExistente);
        return ResponseEntity.ok(clienteAtualizado);
    }

    

   
}
