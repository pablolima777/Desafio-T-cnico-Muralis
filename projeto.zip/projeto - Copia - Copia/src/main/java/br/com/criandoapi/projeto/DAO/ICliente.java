package br.com.criandoapi.projeto.DAO;

import org.springframework.data.repository.CrudRepository;
import br.com.criandoapi.projeto.model.Cliente;

public interface ICliente extends CrudRepository<Cliente, Integer> {
}